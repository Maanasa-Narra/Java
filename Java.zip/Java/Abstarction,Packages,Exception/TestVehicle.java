import com.automobile.twowheeler.Hero;
import com.automobile.twowheeler.Honda;

public class TestVehicle {
    public static void main(String[] args) {
        Hero ob1= new Hero("Hero", "1234", "pooja", 85);
        Honda ob2 = new Honda("Honda", "3425678", "vamsi", 95);
        System.out.println("Model Name: " + ob1.getModelName());
        System.out.println("Registration Number: " + ob1.getRegistrationNumber());
        System.out.println("Owner Name: " + ob1.getOwnerName());
        System.out.println("Speed: " + ob1.getSpeed());
        ob1.radio();
        System.out.println("Model Name: " + ob2.getModelName());
        System.out.println("Registration Number: " + ob2.getRegistrationNumber());
        System.out.println("Owner Name: " + ob2.getOwnerName());
        System.out.println("Speed: " + ob2.getSpeed());
        ob2.cdplayer();
    }
}
