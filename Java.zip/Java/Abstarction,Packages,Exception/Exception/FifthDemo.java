import java.util.Scanner;

class AgeException extends Exception {
    public AgeException(String message) {
        super(message);
    }
}

public class FifthDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the name of person");
        String str=scanner.next();
        System.out.println("enter the age of person");
        int age=scanner.nextInt();
        try{
            if(age>=18 && age<60)
            {
                System.out.println(str);
                System.out.println(age);
            }
            else
            {
                throw new AgeException("error age is not correct");
            }
        }
            catch(AgeException e)
            {
                 System.out.println(e.getMessage());
            }

    }
}