import java.util.Scanner;

class NegativeMarksException extends Exception {
    public NegativeMarksException(String message) {
        super(message);
    }
}

class MarksOutOfRangeException extends Exception {
    public MarksOutOfRangeException(String message) {
        super(message);
    }
}

public class ThridDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[][] marks = new int[2][3];
        String[] subjectNames = {"Subject 1", "Subject 2", "Subject 3"};
        for (int i = 0; i < 2; i++) { 
            System.out.println("Enter the marks for Student ");
            for (int j = 0; j < 3; j++) {
                try {
                    System.out.print("Enter the marks for " + subjectNames[j] + ": ");
                    int mark = Integer.parseInt(scanner.next());

                    if (mark < 0) {
                        throw new NegativeMarksException("Marks cannot be negative");
                    } else if (mark > 100) {
                        throw new MarksOutOfRangeException("Marks cannot exceed 100");
                    }

                    marks[i][j] = mark;
                } catch (NumberFormatException e) {
                    System.out.println("NumberFormatException");
                    j--;
                } catch (NegativeMarksException | MarksOutOfRangeException e) {
                    System.out.println(e.getMessage());
                    j--;
                }
            }
        }
        for (int i = 0; i < 2; i++) {
            int totalMarks = 0;
            for (int j = 0; j < 3; j++) {
                totalMarks += marks[i][j];
            }
            double averageMarks = totalMarks / 3; 
            System.out.println("Average marks of Student "  + averageMarks);
        }

        scanner.close();
    }
}
