import java.util.Scanner;

public class FirstDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of elements in the array:");
        int size = scanner.nextInt();
        int[] array = new int[size];

        System.out.println("Enter the elements:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        FirstDemo arrayAccess = new FirstDemo();

        try {
                System.out.print("Enter the index to access the element");
                String input = scanner.next();
                int index = Integer.parseInt(input);
                arrayAccess.accessElement(array, index);
        }catch (NumberFormatException e) {
                System.out.println("NumberFormatException");
            }
        }
    public void accessElement(int[] array, int index) {
        try {
            System.out.println(array[index]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException");
        }
    }
}
