import java.util.Scanner;
public class SecondDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements ");
        int n=sc.nextInt();
        int[] arr1=new int[n];
        for(int i=0;i<n;i++)
        {
            arr1[i]=sc.nextInt();
        }
        int count=-1;
        int element=sc.nextInt();
        for (int i = 0; i < arr1.length; i++) {
            if (arr1[i] == element) {
                System.out.println(i);
                count=1;
                break;
            }
           }
           if(count==-1)
           {
            System.out.println("-1");
           }

        }
    }
