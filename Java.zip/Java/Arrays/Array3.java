import java.util.Scanner;
public class ThridDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        int[] arr1 = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr1[i] = sc.nextInt();
        }
        int left = 0; 
        for (int i = 0; i < n; i++) {
            if (arr1[i] % 2 == 0) {
                int temp = arr1[left];
                arr1[left] = arr1[i];
                arr1[i] = temp;
                left++; 
            }
        }
        for (int i = 0; i < n; i++) {
            System.out.print(arr1[i] + " ");
        }
    }
}

