import java.util.ArrayList;
import java.util.Iterator;
class Employee {
    private int empId;
    private String empName;
    private String email;
    private String gender;
    public float salary;
    public Employee(int empId, String empName, String email, String gender, float salary) {
        this.empId = empId;
        this.empName = empName;
        this.email = email;
        this.gender = gender;
        this.salary = salary;
    }
    public void getEmployeeDetails() {
        System.out.println("Employee ID: " + empId);
        System.out.println("Name: " + empName);
        System.out.println("Email: " + email);
        System.out.println("Gender: " + gender);
        System.out.println("Salary: " + salary);
    }
    public int getEmpId() {
        return empId;
    }
}

class EmployeeDB {
    private ArrayList<Employee> list;
    public EmployeeDB() {
        list = new ArrayList<>();
    }
    public boolean addEmployee(Employee e) {
        return list.add(e);
    }
    public boolean deleteEmployee(int empId) {
        Iterator<Employee> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getEmpId() == empId) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }
    public String showPaySlip(int empId) {
        for (Employee emp : list) {
            if (emp.getEmpId() == empId) {
                return "Payslip for Employee ID " + empId + ": $" + emp.salary;
            }
        }
        return "Employee with ID " + empId + " not found";
    }

    public ArrayList<Employee> getList() {
        return list;
    }
}
public class EmpolyeeManagement {
    public static void main(String[] args) {
        EmployeeDB empDB = new EmployeeDB();
        empDB.addEmployee(new Employee(1, "pooja", "pooja@example.com", "feMale", 50000.0f));
        empDB.addEmployee(new Employee(2, "hello", "hello@example.com", "Female", 60000.0f));
        System.out.println("Details of all employees:");
        for (Employee emp : empDB.getList()) {
            emp.getEmployeeDetails();
            System.out.println();
        }
        int empIdToDelete = 1;
        if (empDB.deleteEmployee(empIdToDelete)) {
            System.out.println("Employee with ID " + empIdToDelete + " deleted successfully");
        } else {
            System.out.println("Employee with ID " + empIdToDelete + " not found");
        }
        int empIdForPayslip = 2;
        System.out.println(empDB.showPaySlip(empIdForPayslip));
    }
}
