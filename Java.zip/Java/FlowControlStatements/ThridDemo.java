import java.util.Scanner;

public class ThridDemo {

    private String Checking(int num1) {
        if(num1%2==0)
        {
            return "Even";
        }
        else
        {
            return "Odd";
        }
    }

    public static void main(String[] args) {
        ThridDemo ob = new ThridDemo();
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        System.out.println(ob.Checking(num1));
    }
}
