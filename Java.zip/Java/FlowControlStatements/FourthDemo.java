import java.util.Scanner;
public class FourthDemo {
    private String CharacterType(char ch) {
        if (Character.isLetter(ch)) {
            return "Alphabet";
        } else if (Character.isDigit(ch)) {
            return "Digit";
        } else {
            return "Special Character";
        }
    }
    public static void main(String[] args) {
        FourthDemo ob = new FourthDemo();
        Scanner sc = new Scanner(System.in);
        char ch = sc.next().charAt(0);
        System.out.println("The character '" + ch + "' is a " + ob.CharacterType(ch));
    }
}
