import java.util.Scanner;

public class FourthDemo {

    private boolean haveSameLastDigit(int num1, int num2) {
        return (num1 % 10) == (num2 % 10);
    }

    public static void main(String[] args) {
        FourthDemo ob = new FourthDemo();
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        System.out.println(ob.haveSameLastDigit(num1, num2));
    }
}
