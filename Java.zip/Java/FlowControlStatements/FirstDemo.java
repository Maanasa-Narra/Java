import java.util.Scanner;

public class FirstDemo {

    private String Checking(int num1) {
        if(num1>0)
        {
            return "Positive Number";
        }
        else if(num1<0)
        {
            return "Negative Number";
        }
        else
        {
            return "Zero";
        }
    }

    public static void main(String[] args) {
        FirstDemo ob = new FirstDemo();
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        System.out.println(ob.Checking(num1));
    }
}
