import java.util.Scanner;
public class FifthDemo {
    private String FirstCharacter(char ch) {
        switch (Character.toLowerCase(ch)) {
            case 'r':
                return "Red";
            case 'g':
                return "Green";
            case 'b':
                return "Blue";
            case 'y':
                return "Yellow";
            case 'o':
                return "Orange";
            case 'w':
                return "White";
            default:
                return "Unknown color";
        }
    }

    public static void main(String[] args) {
        FifthDemo ob= new FifthDemo();
        Scanner sc = new Scanner(System.in);
        String ch1 = sc.nextLine();
        char ch2=ch1.charAt(0);
        System.out.println(ob.FirstCharacter(ch2));
    }
}
