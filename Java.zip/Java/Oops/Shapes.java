package Oops;
class Shape {
    public void draw() {
        System.out.println("Drawing shape");
    }
    
    public void erase() {
        System.out.println("Erasing shape");
    }
}
class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing circle");
    }
    
    @Override
    public void erase() {
        System.out.println("Erasing a circle");
    }
}

class Triangle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a triangle");
    }
    
    @Override
    public void erase() {
        System.out.println("Erasing a triangle");
    }
}
class Square extends Shape{
    @Override
    public void draw() {
        System.out.println("Drawing a square");
    }
    
    @Override
    public void erase() {
        System.out.println("Erasing a square");
    }
}
public class Shapes {
    public static void main(String[] args) {
        Circle shape;
        

        shape = new Circle();
        shape.draw();
        shape.erase();
        Triangle shape1;

        shape1 = new Triangle();
        shape1.draw();
        shape1.erase();
        Square shape2;

        shape2 = new Square();
        shape2.draw();
        shape2.erase();
    }
}
