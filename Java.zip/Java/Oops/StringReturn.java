package Oops;

import java.util.Scanner;

public class StringReturn {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String str1 = sc.next();
        
        int n = str1.length();
        if (n % 2 == 0) {
            System.out.println("First half of the string: " + str1.substring(0, n / 2));
        } else {
            System.out.println("null");
        }
        
        sc.close(); 
    }
}
