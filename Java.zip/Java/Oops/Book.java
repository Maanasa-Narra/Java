package Oops;

class Author {
    public String name;
    public String Email;
    public char gender; 
    public Author(String name, String Email, char gender) {
        this.name = name;
        this.Email = Email;
        this.gender = gender;
    }
}
public class Book extends Author {
    public String bookName; 
    public double price;
    public int instock;
    
    public Book(String bookName, double price, int instock, String authorName, String authorEmail, char authorGender) {
        super(authorName, authorEmail, authorGender);
        this.bookName = bookName;
        this.price = price;
        this.instock = instock;
    }
    
    public void setBookName(String bookName) {
        this.bookName = bookName;
    }
    
    public String getBookName() {
        return bookName;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setStock(int instock) {
        this.instock = instock;
    }
    
    public int getStock() {
        return instock;
    }
    
    public void display() {
        System.out.println("Author Name: " + super.name);
        System.out.println("Author Email: " + super.Email);
        System.out.println("Author Gender: " + super.gender);
        System.out.println("Book Name: " + this.bookName);
        System.out.println("Book Price: " + this.price);
        System.out.println("Books in Stock: " + this.instock);
    }
    
    public static void main(String[] args) {
        Book book = new Book("Book", 123.45, 10, "pooja", "pooja@example.com", 'F');
        book.display();
    }
}
