package Oops;

import java.util.Scanner;

public class StringReturn4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str1 = sc.next();
        int symbolIndex = str1.indexOf('*');
        if (symbolIndex != -1 && symbolIndex > 0 && symbolIndex < str1.length() - 1) {
            String result = str1.substring(0, symbolIndex - 1) + str1.substring(symbolIndex + 2);
            System.out.println(result);
        } else if (symbolIndex == 0) {
            String result = str1.substring(2); 
            System.out.println(result);
        } else if (symbolIndex == str1.length() - 1) {
            String result = str1.substring(0, symbolIndex - 1); 
            System.out.println(result);
        } else {
            System.out.println(str1);
        }
    }
}
